package records;


public class AYTExamRecord extends Records {
    private String branch;
    private double math, physics, chemistry, biology, literature, history, geo;

    public AYTExamRecord(String branch, double math, double physics, double chemistry, double biology,// Constructor
                         double literature, double history, double geo) {
        this.branch = branch;
        this.math = math;
        this.physics = physics;
        this.chemistry = chemistry;
        this.biology = biology;
        this.literature = literature;
        this.history = history;
        this.geo = geo;
    }

    //Getter
    public String getBranch() {
        return branch;
    }
    
	@Override// AYT Sınavında toplam net alma metodu
	public double getTotalNet() {
		return math + literature + physics + chemistry + biology + history + geo;
	}
}
