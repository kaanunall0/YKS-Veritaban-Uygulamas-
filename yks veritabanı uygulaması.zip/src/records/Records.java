package records;

public abstract class Records {
    private static int studentId;
    // Getters - Setters 
    public static void setStudentId(int id) {
        studentId = id;
    }

    public static int getStudentId() {
        return studentId;
    }
    // Toplam Net Alma Metodu
    public abstract double getTotalNet();
    
}

