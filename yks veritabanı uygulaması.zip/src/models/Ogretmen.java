package models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import database.DatabaseConnector;
import records.Records;

public class Ogretmen extends Person {
    private int ogretmenID;
    private String branch;

    public Ogretmen(String name, String surname, String password) {
        // Gerekirse doldur
    }

    public Ogretmen(String name, String string, String surname, String string2, String password, int i,
                    String string3) {
        // Gerekirse doldur
    }

    public Ogretmen() {
    }

    public int getOgretmenID() {
        return ogretmenID;
    }

    public void setOgretmenID(int ogretmenID) {
        this.ogretmenID = ogretmenID;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public boolean login() {
        String inputId = JOptionPane.showInputDialog(null, "Öğretmen ID giriniz:");
        String password = JOptionPane.showInputDialog(null, "Şifre giriniz:");

        if (inputId == null || password == null) return false;

        try {
            int id = Integer.parseInt(inputId);

            String sql = "SELECT * FROM teacher WHERE teacher_id = ? AND password = ?";
            try (Connection conn = DatabaseConnector.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setInt(1, id);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    this.ogretmenID = id;
                    this.branch = rs.getString("branch");
                    Records.setStudentId(id);
                    JOptionPane.showMessageDialog(null, "Giriş başarılı. Öğretmen ID: " + Records.getStudentId());
                    return true;
                } else {
                    JOptionPane.showMessageDialog(null, "Giriş başarısız! Kullanıcı adı veya şifre yanlış.");
                    return false;
                }
            }
        } catch (NumberFormatException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Giriş hatası: " + e.getMessage());
            return false;
        }
    }
}
