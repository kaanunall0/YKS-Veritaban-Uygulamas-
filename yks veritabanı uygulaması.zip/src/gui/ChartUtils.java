package gui;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import records.AYTExamRecord;
import records.TYTExamRecord;

import javax.swing.*;
import java.util.List;

public class ChartUtils {

    public static void showTYTLineChart(List<TYTExamRecord> records) {// TYT Grafiği metotu
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        int i = 1;
        for (TYTExamRecord rec : records) {
            dataset.addValue(rec.getTotalNet(), "Net", "Sınav " + i);
            i++;
        }

        JFreeChart chart = ChartFactory.createLineChart(
                "TYT Net Gelişimi",
                "Sınavlar",
                "Toplam Net",
                dataset
        );

        ChartPanel panel = new ChartPanel(chart);// TYT Net grafiği
        JFrame frame = new JFrame("TYT Net Grafiği");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(600, 400);// Boyut ayarlama
        frame.setLocationRelativeTo(null);
        frame.add(panel);
        frame.setVisible(true);// Çerçeveyi görünür yapma
    }
    
    public static void showAYTLineChart(List<AYTExamRecord> records) {// AYT Grafiği metotu
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        int i = 1;
        for (AYTExamRecord rec : records) {
            dataset.addValue(rec.getTotalNet(), "Net", "Sınav " + i);
            i++;
        }

        JFreeChart chart = ChartFactory.createLineChart(
                "AYT Net Gelişimi",
                "Sınavlar",
                "Toplam Net",
                dataset
        );

        ChartPanel panel = new ChartPanel(chart);// AYT Net grafiği
        JFrame frame = new JFrame("AYT Net Grafiği");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(600, 400);// Boyut ayarlama
        frame.setLocationRelativeTo(null);
        frame.add(panel);
        frame.setVisible(true);// Çerçeveyi görünür yapma
    }

    
}
