package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import manager.AYTRecordManager;
import manager.RecordManager;

public class AYTEntryForm extends JFrame {

	public AYTEntryForm(int studentId, boolean isExam) {// AYT Sınav kaydı alma
		setTitle(isExam ? "AYT Sınav Kaydı" : "AYT Pratik Kaydı");// Başlık	
		setSize(500, 600);// Boyut ayarlaması
		setLocationRelativeTo(null);
		setLayout(new BorderLayout());

		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		add(mainPanel, BorderLayout.CENTER);

		JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		infoPanel.add(new JLabel("Öğrenci No: " + studentId));
		mainPanel.add(infoPanel);

		JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		datePanel.add(new JLabel("Tarih (YYYY-MM-DD):"));
		JTextField tfDate = new JTextField(15);
		datePanel.add(tfDate);
		mainPanel.add(datePanel);

		String[] branches = { "sayisal", "esit" };
		JComboBox<String> cbBranch = new JComboBox<>(branches);
		JPanel branchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		branchPanel.add(new JLabel("Branş Seçimi:"));
		branchPanel.add(cbBranch);
		mainPanel.add(branchPanel);

		Map<String, String[]> dersMap = new HashMap<>();
		dersMap.put("sayisal", new String[] { "Matematik", "Fizik", "Kimya", "Biyoloji" });
		dersMap.put("esit", new String[] { "Matematik", "Edebiyat", "Tarih", "Coğrafya" });

		JPanel panelInputs = new JPanel();
		panelInputs.setLayout(new BoxLayout(panelInputs, BoxLayout.Y_AXIS));
		JScrollPane scrollPane = new JScrollPane(panelInputs);

		List<JTextField> correctFields = new ArrayList<>();
		List<JTextField> wrongFields = new ArrayList<>();

		cbBranch.addActionListener(e -> {// Branşa göre doğru ve yanlış sayılarını girme
			panelInputs.removeAll();
			correctFields.clear();
			wrongFields.clear();
			String branch = (String) cbBranch.getSelectedItem();
			for (String ders : dersMap.get(branch)) {
				JPanel rowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
				JTextField tfC = new JTextField(5);
				JTextField tfW = new JTextField(5);
				correctFields.add(tfC);
				wrongFields.add(tfW);
				rowPanel.add(new JLabel(ders + " Doğru:"));
				rowPanel.add(tfC);
				rowPanel.add(new JLabel(ders + " Yanlış:"));
				rowPanel.add(tfW);
				panelInputs.add(rowPanel);
			}
			panelInputs.revalidate();
			panelInputs.repaint();
		});

		cbBranch.setSelectedIndex(0);
		mainPanel.add(scrollPane);

		JButton btnSubmit = new JButton("Kaydet");
		btnSubmit.addActionListener(e -> {// Kaydet butonu işlevi
			try {// Hata yakalamak için try-catch bloğu
				String date = tfDate.getText();
				int[] corrects = new int[7];
				int[] wrongs = new int[7];

				String branch = (String) cbBranch.getSelectedItem();
				corrects[0] = Integer.parseInt(correctFields.get(0).getText());
				wrongs[0] = Integer.parseInt(wrongFields.get(0).getText());

				if (branch.equals("sayisal")) {
					for (int i = 1; i <= 3; i++) {
						corrects[i] = Integer.parseInt(correctFields.get(i).getText());
						wrongs[i] = Integer.parseInt(wrongFields.get(i).getText());
					}
				} else {
					for (int i = 1; i <= 3; i++) {
						corrects[i + 4] = Integer.parseInt(correctFields.get(i).getText());
						wrongs[i + 4] = Integer.parseInt(wrongFields.get(i).getText());
					}
				}

				RecordManager manager = new AYTRecordManager();
				if (isExam) {
					manager.insertExam(studentId, date, corrects, wrongs);
				} else {
					manager.insertPractice(studentId, date, corrects, wrongs);
				}

				JOptionPane.showMessageDialog(null, "Kayıt başarıyla eklendi.");
				dispose();
			} catch (NumberFormatException ex) {// Hata çıkınca verilecek olan mesaj
				JOptionPane.showMessageDialog(null, "Tüm alanlara geçerli sayı giriniz!", "Hata",
						JOptionPane.ERROR_MESSAGE);
			}
		});

		JPanel bottomPanel = new JPanel();
		bottomPanel.add(btnSubmit);
		add(bottomPanel, BorderLayout.SOUTH);

		setVisible(true);// Görünür
	}
}