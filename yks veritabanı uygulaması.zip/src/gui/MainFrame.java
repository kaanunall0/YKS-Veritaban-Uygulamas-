package gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import manager.PersonManager;
import models.Ogrenci;
import models.Ogretmen;

public class MainFrame extends JFrame {

    public MainFrame() {
        setTitle("YKS Giriş Ekranı");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ===== LOGO PANELİ (ÜSTTE SABİT) =====
        JPanel logoPanel = new JPanel();
        logoPanel.setBackground(Color.WHITE);

        ImageIcon logoIcon = new ImageIcon(getClass().getResource("/images/logo.png"));
        Image image = logoIcon.getImage().getScaledInstance(220, 80, Image.SCALE_SMOOTH);
        logoIcon = new ImageIcon(image);
        JLabel logoLabel = new JLabel(logoIcon);
        logoPanel.add(logoLabel);
        add(logoPanel, BorderLayout.NORTH);

        // ===== GİRİŞ PANELİ =====
        JPanel rolePanel = new JPanel();
        rolePanel.setLayout(new GridLayout(1, 2, 20, 10));
        JButton btnStudent = new JButton("Öğrenci");
        JButton btnTeacher = new JButton("Öğretmen");
        rolePanel.add(btnStudent);
        rolePanel.add(btnTeacher);
        add(rolePanel, BorderLayout.CENTER);

        btnStudent.addActionListener(e -> showStudentMenu());
        btnTeacher.addActionListener(e -> showTeacherLogin());
    }
 
    private void showStudentMenu() {
        JFrame menuFrame = new JFrame("Öğrenci Seçimi");
        menuFrame.setSize(300, 150);
        menuFrame.setLocationRelativeTo(null);
        menuFrame.setLayout(new GridLayout(2, 1, 10, 10));

        JButton btnLogin = new JButton("Giriş Yap");
        JButton btnRegister = new JButton("Kayıt Ol");

        btnLogin.addActionListener(e -> {
            menuFrame.dispose();
            showStudentLoginForm();
        });

        btnRegister.addActionListener(e -> {
            menuFrame.dispose();
            showStudentRegisterForm();
        });

        menuFrame.add(btnLogin);
        menuFrame.add(btnRegister);
        menuFrame.setVisible(true);
    }

    private void showStudentLoginForm() {
        JFrame loginFrame = new JFrame("Öğrenci Girişi");
        loginFrame.setSize(400, 250);
        loginFrame.setLocationRelativeTo(null);
        loginFrame.setLayout(new GridLayout(4, 2, 5, 5));

        JTextField tfName = new JTextField();
        JTextField tfSurname = new JTextField();
        JPasswordField pfPassword = new JPasswordField();

        loginFrame.add(new JLabel("Ad:"));
        loginFrame.add(tfName);
        loginFrame.add(new JLabel("Soyad:"));
        loginFrame.add(tfSurname);
        loginFrame.add(new JLabel("Şifre:"));
        loginFrame.add(pfPassword);

        JButton btnLogin = new JButton("Giriş Yap");
        loginFrame.add(new JLabel());
        loginFrame.add(btnLogin);

        btnLogin.addActionListener(e -> {
            String name = tfName.getText().trim();
            String surname = tfSurname.getText().trim();
            String password = new String(pfPassword.getPassword());

            if (PersonManager.validateUser(name, surname, password)) {
                // Öğrenci numarasını veritabanından çek
                int studentNo = PersonManager.getStudentNo(name, surname, password);

                if (studentNo != -1) {
                    JOptionPane.showMessageDialog(loginFrame, "Giriş başarılı!");
                    Ogrenci ogrenci = new Ogrenci(name, surname, password, studentNo, "");
                    new StudentMenu(ogrenci).setVisible(true);
                    loginFrame.dispose();
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(loginFrame, "Öğrenci numarası bulunamadı!", "Hata", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(loginFrame, "Geçersiz öğrenci bilgileri!");
            }
        });

        loginFrame.setVisible(true);
    }


    private void showStudentRegisterForm() {
        JFrame registerFrame = new JFrame("Öğrenci Kaydı");
        registerFrame.setSize(400, 350);
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setLayout(new GridLayout(7, 2, 5, 5));

        JTextField tfName = new JTextField();
        JTextField tfSurname = new JTextField();
        JTextField tfPhone = new JTextField();
        JTextField tfStudentNo = new JTextField();
        JTextField tfSchool = new JTextField();
        JPasswordField pfPassword = new JPasswordField();

        registerFrame.add(new JLabel("Ad:"));
        registerFrame.add(tfName);
        registerFrame.add(new JLabel("Soyad:"));
        registerFrame.add(tfSurname);
        registerFrame.add(new JLabel("Telefon:"));
        registerFrame.add(tfPhone);
        registerFrame.add(new JLabel("Öğrenci No:"));
        registerFrame.add(tfStudentNo);
        registerFrame.add(new JLabel("Okul:"));
        registerFrame.add(tfSchool);
        registerFrame.add(new JLabel("Şifre:"));
        registerFrame.add(pfPassword);

        JButton btnRegister = new JButton("Kaydol");
        registerFrame.add(new JLabel());
        registerFrame.add(btnRegister);

        btnRegister.addActionListener(e -> {
            String name = tfName.getText().trim();
            String surname = tfSurname.getText().trim();
            String phone = tfPhone.getText().trim();
            String studentNoStr = tfStudentNo.getText().trim();
            String school = tfSchool.getText().trim();
            String password = new String(pfPassword.getPassword());

            if (name.isEmpty() || surname.isEmpty() || phone.isEmpty() || studentNoStr.isEmpty() || school.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(registerFrame, "Lütfen tüm alanları doldurun!");
                return;
            }

            int studentNo;
            try {
                studentNo = Integer.parseInt(studentNoStr);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(registerFrame, "Öğrenci numarası sayısal olmalıdır!");
                return;
            }

            boolean result = PersonManager.addStudent(name, surname, phone, studentNo, school, password);
            JOptionPane.showMessageDialog(registerFrame, result ? "Kayıt başarılı!" : "Kayıt başarısız!");
        });

        registerFrame.setVisible(true);
    }

    private void showTeacherLogin() {
        JFrame menuFrame = new JFrame("Öğretmen Seçimi");
        menuFrame.setSize(300, 150);
        menuFrame.setLocationRelativeTo(null);
        menuFrame.setLayout(new GridLayout(2, 1, 10, 10));

        JButton btnLogin = new JButton("Giriş Yap");
        JButton btnRegister = new JButton("Kayıt Ol");

        btnLogin.addActionListener(e -> {
            menuFrame.dispose();
            showTeacherLoginForm();
        });

        btnRegister.addActionListener(e -> {
            menuFrame.dispose();
            showTeacherRegisterForm();
        });

        menuFrame.add(btnLogin);
        menuFrame.add(btnRegister);
        menuFrame.setVisible(true);
    }

    private void showTeacherLoginForm() {
        JFrame loginFrame = new JFrame("Öğretmen Girişi");
        loginFrame.setSize(400, 250);
        loginFrame.setLocationRelativeTo(null);
        loginFrame.setLayout(new GridLayout(4, 2, 5, 5));

        JTextField tfName = new JTextField();
        JTextField tfSurname = new JTextField();
        JPasswordField pfPassword = new JPasswordField();

        loginFrame.add(new JLabel("Ad:"));
        loginFrame.add(tfName);
        loginFrame.add(new JLabel("Soyad:"));
        loginFrame.add(tfSurname);
        loginFrame.add(new JLabel("Şifre:"));
        loginFrame.add(pfPassword);

        JButton btnLogin = new JButton("Giriş Yap");
        loginFrame.add(new JLabel());
        loginFrame.add(btnLogin);

        btnLogin.addActionListener(e -> {
            String name = tfName.getText().trim();
            String surname = tfSurname.getText().trim();
            String password = new String(pfPassword.getPassword());

            if (PersonManager.validateTeacher(name, surname, password)) {
                JOptionPane.showMessageDialog(loginFrame, "Giriş başarılı!");

                // Öğretmen nesnesini oluştur
                Ogretmen ogretmen = new Ogretmen(name, surname, password);

                // GUI tabanlı TeacherMenu ekranını aç
                TeacherMenu teacherMenu = new TeacherMenu();
                teacherMenu.setVisible(true);

                loginFrame.dispose();
                dispose(); // Ana frame'i de kapatmak istiyorsan
            } else {
                JOptionPane.showMessageDialog(loginFrame, "Geçersiz öğretmen bilgileri!");
            }
        });

        loginFrame.setVisible(true);
    }

    private void showTeacherRegisterForm() {
        JFrame registerFrame = new JFrame("Öğretmen Kaydı");
        registerFrame.setSize(400, 350);
        registerFrame.setLocationRelativeTo(null);
        registerFrame.setLayout(new GridLayout(7, 2, 5, 5));

        JTextField tfName = new JTextField();
        JTextField tfSurname = new JTextField();
        JTextField tfPhone = new JTextField();
        JTextField tfTeacherId = new JTextField();
        JTextField tfBranch = new JTextField();
        JPasswordField pfPassword = new JPasswordField();

        registerFrame.add(new JLabel("Ad:"));
        registerFrame.add(tfName);
        registerFrame.add(new JLabel("Soyad:"));
        registerFrame.add(tfSurname);
        registerFrame.add(new JLabel("Telefon:"));
        registerFrame.add(tfPhone);
        registerFrame.add(new JLabel("Öğretmen No:"));
        registerFrame.add(tfTeacherId);
        registerFrame.add(new JLabel("Branş:"));
        registerFrame.add(tfBranch);
        registerFrame.add(new JLabel("Şifre:"));
        registerFrame.add(pfPassword);

        JButton btnRegister = new JButton("Kaydol");
        registerFrame.add(new JLabel());
        registerFrame.add(btnRegister);

        btnRegister.addActionListener(e -> {
            String name = tfName.getText().trim();
            String surname = tfSurname.getText().trim();
            String phone = tfPhone.getText().trim();
            String teacherIdStr = tfTeacherId.getText().trim();
            String branch = tfBranch.getText().trim();
            String password = new String(pfPassword.getPassword());

            if (name.isEmpty() || surname.isEmpty() || phone.isEmpty() || teacherIdStr.isEmpty() || branch.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(registerFrame, "Lütfen tüm alanları doldurun!");
                return;
            }

            int teacherId;
            try {
                teacherId = Integer.parseInt(teacherIdStr);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(registerFrame, "Öğretmen numarası sayısal olmalıdır!");
                return;
            }

            boolean result = PersonManager.addTeacher(name, surname, phone, teacherId, branch, password);
            JOptionPane.showMessageDialog(registerFrame, result ? "Kayıt başarılı!" : "Kayıt başarısız!");
        });

        registerFrame.setVisible(true);
    }
}
