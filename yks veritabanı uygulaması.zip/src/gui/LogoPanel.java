package gui;

import javax.swing.*;
import java.awt.*;

public class LogoPanel extends JFrame {

    public LogoPanel() {
        setTitle("Sabit Logo Paneli");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Ana panel: BorderLayout ile düzenlenmiş
        JPanel mainPanel = new JPanel(new BorderLayout());

        // LOGO PANELİ: Üstte sabit kalacak panel
        JPanel logoPanel = new JPanel();
        logoPanel.setBackground(Color.WHITE);

        // Logo yüklüyoruz (resources/images/logo.png dosyasından)
        ImageIcon logoIcon = new ImageIcon(getClass().getResource("/images/logo.png"));

        // Gerekirse logo boyutlandırma (örneğin 100x100 px)
        Image image = logoIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        logoIcon = new ImageIcon(image);

        // JLabel içine logoyu ekle
        JLabel logoLabel = new JLabel(logoIcon);
        logoPanel.add(logoLabel);

        // ORTA PANEL: Diğer içerikler
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new GridLayout(2, 1, 10, 10));
        contentPanel.add(new JButton("Birinci Buton"));
        contentPanel.add(new JButton("İkinci Buton"));

        // Panelleri ana panele ekle
        mainPanel.add(logoPanel, BorderLayout.NORTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        // Ana paneli frame'e ekle
        add(mainPanel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LogoPanel());
    }
}
