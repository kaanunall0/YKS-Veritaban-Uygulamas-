
package gui;

import javax.swing.*;
import java.awt.*;
import manager.TYTRecordManager;
import manager.RecordManager;

public class TYTEntryForm extends JFrame {

    public TYTEntryForm(int studentId, boolean isExam) {// TYT Sınav Kaydı Alma
        setTitle(isExam ? "TYT Sınav Kaydı" : "TYT Pratik Kaydı");// Başlık
        setSize(500, 600);// Boyut ayarlama
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        add(mainPanel, BorderLayout.CENTER);

        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        infoPanel.add(new JLabel("Öğrenci No: " + studentId));
        mainPanel.add(infoPanel);

        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        datePanel.add(new JLabel("Tarih (YYYY-MM-DD):"));
        JTextField tfDate = new JTextField(15);
        datePanel.add(tfDate);
        mainPanel.add(datePanel);

        String[] subjects = {"Matematik", "Türkçe", "Fizik", "Kimya", "Biyoloji", "Tarih", "Coğrafya"};// Dersler
        JTextField[] correctFields = new JTextField[7];
        JTextField[] wrongFields = new JTextField[7];

        for (int i = 0; i < subjects.length; i++) {// Ders sayısına göre satır ekler ve doğru yanlışları girer
            JPanel rowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            correctFields[i] = new JTextField(5);
            wrongFields[i] = new JTextField(5);
            rowPanel.add(new JLabel(subjects[i] + " Doğru:"));
            rowPanel.add(correctFields[i]);
            rowPanel.add(new JLabel(subjects[i] + " Yanlış:"));
            rowPanel.add(wrongFields[i]);
            mainPanel.add(rowPanel);
        }

        JButton btnSubmit = new JButton("Kaydet");// Kaydet butonu
        btnSubmit.addActionListener(e -> {// Kaydet butonu görev ataması
            try {// Hata yakalamak için try-catch bloğu
                String date = tfDate.getText();
                int[] corrects = new int[7];
                int[] wrongs = new int[7];
                for (int i = 0; i < 7; i++) {
                    corrects[i] = Integer.parseInt(correctFields[i].getText());
                    wrongs[i] = Integer.parseInt(wrongFields[i].getText());
                }
                RecordManager manager = new TYTRecordManager();
                if (isExam) {
                    manager.insertExam(studentId, date, corrects, wrongs);
                } else {
                    manager.insertPractice(studentId, date, corrects, wrongs);
                }
                JOptionPane.showMessageDialog(null, "Kayıt başarıyla eklendi.");
                dispose();
            } catch (NumberFormatException ex) {// Geçersiz sayı girildiğinde verilecek mesaj
                JOptionPane.showMessageDialog(null, "Tüm alanlara geçerli sayı girin!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(btnSubmit);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);// görünür
    }
}
