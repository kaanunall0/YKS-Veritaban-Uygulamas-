
package gui;

import java.awt.GridLayout;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import manager.AYTRecordManager;
import manager.TYTRecordManager;
import models.Ogrenci;
import records.AYTExamRecord;
import records.AYTPracticeRecord;
import records.TYTExamRecord;
import records.TYTPracticeRecord;

public class StudentMenu extends JFrame {// Öğrenci Menüsü

    private Ogrenci ogrenci;

    public StudentMenu(Ogrenci ogrenci) {
        this.ogrenci = ogrenci;
        setTitle("Öğrenci Menüsü - " + ogrenci.getName());// Başlık ayarlaması
        setSize(600, 550);//Boyut ayarlaması
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(10, 1, 10, 10));
        // Sınav-pratik ekleme, sonuç gösterme ve grafik gösterme butonları
        JButton btnAddTYTExam = new JButton("TYT Sınav Ekle");
        JButton btnAddTYTPractice = new JButton("TYT Pratik Ekle");
        JButton btnAddAYTExam = new JButton("AYT Sınav Ekle");
        JButton btnAddAYTPractice = new JButton("AYT Pratik Ekle");

        JButton btnViewTYTExam = new JButton("TYT Sınav Sonuçları");
        JButton btnViewTYTPractice = new JButton("TYT Pratik Sonuçları");
        JButton btnViewAYTExam = new JButton("AYT Sınav Sonuçları");
        JButton btnViewAYTPractice = new JButton("AYT Pratik Sonuçları");

        JButton btnChartTYT = new JButton("TYT Net Grafiği");
        JButton btnChartAyt  = new JButton("AYT Net Grafiği");

        JButton btnExit = new JButton("Çıkış");// Çıkış butonu

        btnAddTYTExam.addActionListener(e -> new TYTEntryForm(ogrenci.getStudentNo(), true));
        btnAddTYTPractice.addActionListener(e -> new TYTEntryForm(ogrenci.getStudentNo(), false));
        btnAddAYTExam.addActionListener(e -> new AYTEntryForm(ogrenci.getStudentNo(), true));
        btnAddAYTPractice.addActionListener(e -> new AYTEntryForm(ogrenci.getStudentNo(), false));

        btnViewTYTExam.addActionListener(e -> {// TYT Sınavı Görüntüleme Butonu
            List<TYTExamRecord> records = TYTRecordManager.getExamRecords(ogrenci.getStudentNo());
            if (records.isEmpty()) {//Hiç TYT Sınavı Girilmemişse Çalışır
                JOptionPane.showMessageDialog(null, "TYT sınav kaydı bulunamadı.");
                return;
            }
            double total = 0, max = Double.NEGATIVE_INFINITY, min = Double.POSITIVE_INFINITY;
            for (TYTExamRecord rec : records) {// Maksimum ve minimum sınav netini bulma
                double net = rec.getTotalNet();
                total += net;
                if (net > max) max = net;
                if (net < min) min = net;
            }
            double avg = total / records.size();
            JOptionPane.showMessageDialog(null, "Max: " + max + "\nMin: " + min + "\nOrtalama: " + avg,// Maksimum, minumum ve ortalama sınav netini gösterme 
                                          "TYT Sınav Sonuçları", JOptionPane.INFORMATION_MESSAGE);
        });

        btnViewTYTPractice.addActionListener(e -> {// TYT Pratiği Görüntüleme Butonu
            List<TYTPracticeRecord> records = TYTRecordManager.getPracticeRecords(ogrenci.getStudentNo());
            if (records.isEmpty()) {//Hiç TYT Pratiği Girilmemişse Çalışır
                JOptionPane.showMessageDialog(null, "TYT pratik kaydı bulunamadı.");
                return;
            }
            double total = 0, max = Double.NEGATIVE_INFINITY, min = Double.POSITIVE_INFINITY;
            for (TYTPracticeRecord rec : records) {// Maksimum ve minimum pratik netini bulma
                double net = rec.getTotalNet();
                total += net;
                if (net > max) max = net;
                if (net < min) min = net;
            }
            double avg = total / records.size();
            JOptionPane.showMessageDialog(null, "Max: " + max + "\nMin: " + min + "\nOrtalama: " + avg,// Maksimum, minumum ve ortalama pratik netini gösterme
                                          "TYT Pratik Sonuçları", JOptionPane.INFORMATION_MESSAGE);
        });

        btnViewAYTExam.addActionListener(e -> {// AYT Sınavı Görüntüleme Butonu
            List<AYTExamRecord> records = AYTRecordManager.getExamRecords(ogrenci.getStudentNo());
            if (records.isEmpty()) {//Hiç AYT Sınavı Girilmemişse Çalışır
                JOptionPane.showMessageDialog(null, "AYT sınav kaydı bulunamadı.");
                return;
            }
            double total = 0, max = Double.NEGATIVE_INFINITY, min = Double.POSITIVE_INFINITY;
            for (AYTExamRecord rec : records) {// Maksimum ve minimum sınav netini bulma
                double net = rec.getTotalNet();
                total += net;
                if (net > max) max = net;
                if (net < min) min = net;
            }
            double avg = total / records.size();
            JOptionPane.showMessageDialog(null, "Max: " + max + "\nMin: " + min + "\nOrtalama: " + avg,// Maksimum, minumum ve ortalama sınav netini gösterme
                                          "AYT Sınav Sonuçları", JOptionPane.INFORMATION_MESSAGE);
        });

        btnViewAYTPractice.addActionListener(e -> {// AYT Pratiği Görüntüleme Butonu
            List<AYTPracticeRecord> records = AYTRecordManager.getPracticeRecords(ogrenci.getStudentNo());
            if (records.isEmpty()) {//Hiç AYT Pratiği Girilmemişse Çalışır
                JOptionPane.showMessageDialog(null, "AYT pratik kaydı bulunamadı.");
                return;
            }
            double total = 0, max = Double.NEGATIVE_INFINITY, min = Double.POSITIVE_INFINITY;
            for (AYTPracticeRecord rec : records) {// Maksimum ve minimum pratik netini bulma
                double net = rec.getTotalNet();
                total += net;
                if (net > max) max = net;
                if (net < min) min = net;
            }
            double avg = total / records.size();
            JOptionPane.showMessageDialog(null, "Max: " + max + "\nMin: " + min + "\nOrtalama: " + avg,// Maksimum, minumum ve ortalama pratik netini gösterme
                                          "AYT Pratik Sonuçları", JOptionPane.INFORMATION_MESSAGE);
        });

        btnChartTYT.addActionListener(e -> {// TYT Sınavı Grafiği Gösterme Butonu Görev Ataması
            List<TYTExamRecord> records = TYTRecordManager.getExamRecords(ogrenci.getStudentNo());
            ChartUtils.showTYTLineChart(records);
        });
        
        btnChartAyt.addActionListener(e->{// AYT Sınavı Grafiği Gösterme Butonu Görev Ataması
        	List<AYTExamRecord> records = AYTRecordManager.getExamRecords(ogrenci.getStudentNo());
        	ChartUtils.showAYTLineChart(records);
        });

        btnExit.addActionListener(e -> dispose());// Çıkış butonu görev ataması
        // Butonları ekleme
        add(btnAddTYTExam);
        add(btnAddTYTPractice);
        add(btnAddAYTExam);
        add(btnAddAYTPractice);
        add(btnViewTYTExam);
        add(btnViewTYTPractice);
        add(btnViewAYTExam);
        add(btnViewAYTPractice);
        add(btnChartTYT);
        add(btnChartAyt);
        add(btnExit);
    }
}
