
package manager;

import database.DatabaseConnector;
import records.TYTExamRecord;
import records.TYTPracticeRecord;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TYTRecordManager extends RecordManager {// TYT Sınavı Kayıt

    public static void insertExam(int studentId) {// Sınav ekleme metodu
        try {// Hata yakalamak için try-catch bloğu
            String date = JOptionPane.showInputDialog("Tarih (YYYY-MM-DD):");// Tarih Girme
            double math = Double.parseDouble(JOptionPane.showInputDialog("Matematik Net:"));
            double turkish = Double.parseDouble(JOptionPane.showInputDialog("Türkçe Net:"));
            double physics = Double.parseDouble(JOptionPane.showInputDialog("Fizik Net:"));
            double chemistry = Double.parseDouble(JOptionPane.showInputDialog("Kimya Net:"));
            double biology = Double.parseDouble(JOptionPane.showInputDialog("Biyoloji Net:"));
            double history = Double.parseDouble(JOptionPane.showInputDialog("Tarih Net:"));
            double geo = Double.parseDouble(JOptionPane.showInputDialog("Coğrafya Net:"));

            String sql = "INSERT INTO TYTExamRecord (student_id, date, math, turkish, physics, chemistry, biology, history, geo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";// TYT Sınav Kayıtları Tablosuna Değer Ekleme
            try (Connection conn = DatabaseConnector.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {// Hata yakalamak için try-catch bloğu
                stmt.setInt(1, studentId);
                stmt.setString(2, date);
                stmt.setDouble(3, math);
                stmt.setDouble(4, turkish);
                stmt.setDouble(5, physics);
                stmt.setDouble(6, chemistry);
                stmt.setDouble(7, biology);
                stmt.setDouble(8, history);
                stmt.setDouble(9, geo);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "TYT sınav kaydı başarıyla eklendi.");
            }
        } catch (Exception e) {// Hata yakalandığında verilecek mesaj
            JOptionPane.showMessageDialog(null, "Hata: " + e.getMessage());
        }
    }

    public static void insertPractice(int studentId) {// Pratik Ekleme Metodu
        try {// Hata yakalamak için try-catch bloğu
            String date = JOptionPane.showInputDialog("Tarih (YYYY-MM-DD):");
            double math = Double.parseDouble(JOptionPane.showInputDialog("Matematik Net:"));
            double turkish = Double.parseDouble(JOptionPane.showInputDialog("Türkçe Net:"));
            double physics = Double.parseDouble(JOptionPane.showInputDialog("Fizik Net:"));
            double chemistry = Double.parseDouble(JOptionPane.showInputDialog("Kimya Net:"));
            double biology = Double.parseDouble(JOptionPane.showInputDialog("Biyoloji Net:"));
            double history = Double.parseDouble(JOptionPane.showInputDialog("Tarih Net:"));
            double geo = Double.parseDouble(JOptionPane.showInputDialog("Coğrafya Net:"));

            String sql = "INSERT INTO TYTPracticeRecord (student_id, date, math, turkish, physics, chemistry, biology, history, geo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";// TYT Pratik Kayıtları Tablosuna Değer Ekleme
            try (Connection conn = DatabaseConnector.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {// Hata yakalamak için try-catch bloğu
                stmt.setInt(1, studentId);
                stmt.setString(2, date);
                stmt.setDouble(3, math);
                stmt.setDouble(4, turkish);
                stmt.setDouble(5, physics);
                stmt.setDouble(6, chemistry);
                stmt.setDouble(7, biology);
                stmt.setDouble(8, history);
                stmt.setDouble(9, geo);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "TYT pratik kaydı başarıyla eklendi.");
            }
        } catch (Exception e) {// Hata yakalandığında verilecek mesaj
            JOptionPane.showMessageDialog(null, "Hata: " + e.getMessage());
        }
    }

    public static List<TYTExamRecord> getExamRecords(int studentId) {// Sınav kaydı görme 
        List<TYTExamRecord> records = new ArrayList<>();
        String sql = "SELECT * FROM TYTExamRecord WHERE student_id = ?";// TYTExamRecords'tan girilen ID'ye ait öğrenciyi gösterir
        try (Connection conn = DatabaseConnector.getConnection();// Hata yakalamak için try-catch bloğu
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                records.add(new TYTExamRecord(
                    rs.getDouble("math"),
                    rs.getDouble("turkish"),
                    rs.getDouble("physics"),
                    rs.getDouble("chemistry"),
                    rs.getDouble("biology"),
                    rs.getDouble("history"),
                    rs.getDouble("geo")
                ));
            }
        } catch (SQLException e) {// Hata yakalandığında verilecek mesaj
            e.printStackTrace();
        }
        return records;
    }

    public static List<TYTPracticeRecord> getPracticeRecords(int studentId) {// Pratik Kaydı Görme
        List<TYTPracticeRecord> records = new ArrayList<>();
        String sql = "SELECT * FROM TYTPracticeRecord WHERE student_id = ?";// TYTPracticeRecords'tan girilen ID'ye ait öğrenciyi gösterir
        try (Connection conn = DatabaseConnector.getConnection();// Hata yakalamak için try-catch bloğu
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                records.add(new TYTPracticeRecord(
                    rs.getDouble("math"),
                    rs.getDouble("turkish"),
                    rs.getDouble("physics"),
                    rs.getDouble("chemistry"),
                    rs.getDouble("biology"),
                    rs.getDouble("history"),
                    rs.getDouble("geo")
                ));
            }
        } catch (SQLException e) {// Hata yakalandığında verilecek mesaj
            e.printStackTrace();
        }
        return records;
    }

  
    
    @Override// Override Metod
    public void insertExam(int studentId, String date, int[] corrects, int[] wrongs) {
        double[] netler = new double[7];
        for (int i = 0; i < 7; i++) {
            netler[i] = corrects[i] - (wrongs[i] * 0.25);
        }

        String sql = "INSERT INTO TYTExamRecord (student_id, date, math, turkish, physics, chemistry, biology, history, geo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();// Hata yakalamak için try-catch bloğu
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setString(2, date);
            for (int i = 0; i < 7; i++) {
                stmt.setDouble(i + 3, netler[i]);
            }
            stmt.executeUpdate();
        } catch (SQLException e) {// Hata yakalandığında verilecek mesaj
            e.printStackTrace();
        }
    }

    @Override// Override Metod
    public void insertPractice(int studentId, String date, int[] corrects, int[] wrongs) {
        double[] netler = new double[7];
        for (int i = 0; i < 7; i++) {
            netler[i] = corrects[i] - (wrongs[i] * 0.25);
        }

        String sql = "INSERT INTO TYTPracticeRecord (student_id, date, math, turkish, physics, chemistry, biology, history, geo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();// Hata yakalamak için try-catch bloğu
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setString(2, date);
            for (int i = 0; i < 7; i++) {
                stmt.setDouble(i + 3, netler[i]);
            }
            stmt.executeUpdate();
        } catch (SQLException e) {// Hata yakalandığında verilecek mesaj
            e.printStackTrace();
        }
    }
}
