package manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import database.DatabaseConnector;

public class PersonManager {// Tablo işlemleri

    public static boolean addTeacher(String name, String surname, String phoneNumber, int ogretmenID, String branch, String password) {// Öğretmen ekleme tablosu
        String sql = "INSERT INTO teacher (name, surname, phoneNumber, teacher_id, branch, password) VALUES (?, ?, ?, ?, ?, ?)";//Öğretmen bilgileri
        try (Connection conn = DatabaseConnector.getConnection();//Hata yakalamak için try-catch bloğu
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, surname);
            stmt.setString(3, phoneNumber);
            stmt.setInt(4, ogretmenID);
            stmt.setString(5, branch);
            stmt.setString(6, password);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {// Hata yakalandığında verilecek olan mesaj 
            System.err.println("Öğretmen ekleme hatası: " + e.getMessage());
            return false;
        }
    }

    public static boolean addStudent(String name, String surname, String phoneNumber, int studentNo, String school, String password) {// Öğrenci ekleme tablosu
        String sql = "INSERT INTO student (name, surname, phoneNumber, studentNo, school, password) VALUES (?, ?, ?, ?, ?, ?)";//Öğrenci bilgileri
        try (Connection conn = DatabaseConnector.getConnection();//Hata yakalamak için try-catch bloğu
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, surname);
            stmt.setString(3, phoneNumber);
            stmt.setInt(4, studentNo);
            stmt.setString(5, school);
            stmt.setString(6, password);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {// Hata yakalandığında verilecek olan mesaj 
            System.err.println("Öğrenci ekleme hatası: " + e.getMessage());
            return false;
        }
    }

    // Giriş yapan öğrenciyi student tablosuna göre doğrular
    public static boolean validateUser(String name, String surname, String password) {
        String sql = "SELECT * FROM student WHERE name = ? AND surname = ? AND password = ?";

        try (Connection conn = DatabaseConnector.getConnection();//Hata yakalamak için try-catch boğu
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, surname);
            stmt.setString(3, password);

            ResultSet rs = stmt.executeQuery();
            return rs.next(); // kayıt bulunduysa true

        } catch (SQLException e) {// Hata yakalandığında verilecek olan mesaj
            e.printStackTrace();
            return false;
        }
    }

 // Giriş yapan öğretmeni teacher tablosuna göre doğrular
    public static boolean validateTeacher(String name, String surname, String password) {
        String query = "SELECT * FROM teacher WHERE name = ? AND surname = ? AND password = ?";
        try (Connection conn = DatabaseConnector.getConnection();//Hata yakalamak için try-catch boğu
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, surname);
            stmt.setString(3, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();// kayıt bulunduysa true
        } catch (SQLException e) {// Hata yakalandığında verilecek olan mesaj
            e.printStackTrace();
            return false;
        }
    }
    
    // Giriş yapan öğrencinin öğrenci numarasını getirir
    public static int getStudentNo(String name, String surname, String password) {
        String sql = "SELECT studentNo FROM student WHERE name = ? AND surname = ? AND password = ?";

        try (Connection conn = DatabaseConnector.getConnection();//Hata yakalamak için try-catch boğu
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, surname);
            stmt.setString(3, password);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("studentNo");
            }

        } catch (SQLException e) {// Hata yakalandığında verilecek olan mesaj
            e.printStackTrace();
        }

        return -1; // bulunamazsa
    }
}
