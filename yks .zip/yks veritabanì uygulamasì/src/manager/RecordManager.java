package manager;

public abstract class RecordManager {
	
	public abstract void insertExam(int studentId, String date, int[] corrects, int[] wrongs);// Sınav ekleme metotu
    public abstract void insertPractice(int studentId, String date, int[] corrects, int[] wrongs);// Pratik ekleme metotu
	
}
