
package manager;

import database.DatabaseConnector;
import records.AYTExamRecord;
import records.AYTPracticeRecord;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AYTRecordManager extends RecordManager {// AYT Sınavı Kayıt

    public static void insertExam(int studentId) {// Sınav Ekleme Metotu
        try {// Hata yakalamak için try-catch bloğu
            String date = JOptionPane.showInputDialog("Tarih (YYYY-MM-DD):");// Tarih girme
            String branch = JOptionPane.showInputDialog("Branş (sayisal / esit):").toLowerCase();// Sayısal- Eşit Ağırlık Seçimi

            double math = Double.parseDouble(JOptionPane.showInputDialog("Matematik Net:"));
            double physics = 0, chemistry = 0, biology = 0, literature = 0, history = 0, geo = 0;

            if (branch.equals("sayisal")) {// Sayısal Seçildiğinde Çalışır
                physics = Double.parseDouble(JOptionPane.showInputDialog("Fizik Net:"));
                chemistry = Double.parseDouble(JOptionPane.showInputDialog("Kimya Net:"));
                biology = Double.parseDouble(JOptionPane.showInputDialog("Biyoloji Net:"));
            } else if (branch.equals("esit")) {// Eşit Ağırlık Seçildiğinde Çalışır
                literature = Double.parseDouble(JOptionPane.showInputDialog("Edebiyat Net:"));
                history = Double.parseDouble(JOptionPane.showInputDialog("Tarih Net:"));
                geo = Double.parseDouble(JOptionPane.showInputDialog("Coğrafya Net:"));
            } else {// Yanlış veya Geçersiz Branş Girildiğinde Yazılacak Mesaj
                JOptionPane.showMessageDialog(null, "Geçersiz branş girdiniz (sayisal / esit olmalı).");
                return;
            }

            String sql = "INSERT INTO AYTExamRecord (student_id, date, branch, math, physics, chemistry, biology, literature, history, geo) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";// AYT Kayıtları Tablosuna Değer Ekleme
            try (Connection conn = DatabaseConnector.getConnection();// Hata yakalamak için try-catch bloğu
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, studentId);
                stmt.setString(2, date);
                stmt.setString(3, branch);
                stmt.setDouble(4, math);
                stmt.setDouble(5, physics);
                stmt.setDouble(6, chemistry);
                stmt.setDouble(7, biology);
                stmt.setDouble(8, literature);
                stmt.setDouble(9, history);
                stmt.setDouble(10, geo);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "AYT sınav kaydı başarıyla eklendi.");
            }
        } catch (Exception e) {// Hata yakalandığında verilecek mesaj
            JOptionPane.showMessageDialog(null, "Hata: " + e.getMessage());
        }
    }

    public static void insertPractice(int studentId) {// Pratik Ekleme Metodu
        try {// Hata yakalamak için try-catch bloğu
            String date = JOptionPane.showInputDialog("Tarih (YYYY-MM-DD):");// Tarih girme 
            String branch = JOptionPane.showInputDialog("Branş (sayisal / esit):").toLowerCase();// Sayısal- Eşit Ağırlık Seçimi

            double math = Double.parseDouble(JOptionPane.showInputDialog("Matematik Net:"));
            double physics = 0, chemistry = 0, biology = 0, literature = 0, history = 0, geo = 0;

            if (branch.equals("sayisal")) {// Sayısal Seçildiğinde Çalışır
                physics = Double.parseDouble(JOptionPane.showInputDialog("Fizik Net:"));
                chemistry = Double.parseDouble(JOptionPane.showInputDialog("Kimya Net:"));
                biology = Double.parseDouble(JOptionPane.showInputDialog("Biyoloji Net:"));
            } else if (branch.equals("esit")) {// Eşit Ağırlık Seçildiğinde Çalışır
                literature = Double.parseDouble(JOptionPane.showInputDialog("Edebiyat Net:"));
                history = Double.parseDouble(JOptionPane.showInputDialog("Tarih Net:"));
                geo = Double.parseDouble(JOptionPane.showInputDialog("Coğrafya Net:"));
            } else {// Yanlış veya Geçersiz Branş Girildiğinde Yazılacak Mesaj
                JOptionPane.showMessageDialog(null, "Geçersiz branş girdiniz (sayisal / esit olmalı).");
                return;
            }

            String sql = "INSERT INTO AYTPracticeRecord (student_id, date, branch, math, physics, chemistry, biology, literature, history, geo) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";// AYT Kayıtları Tablosuna Değer Ekleme
            try (Connection conn = DatabaseConnector.getConnection();// Hata yakalamak için try-catch bloğu
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, studentId);
                stmt.setString(2, date);
                stmt.setString(3, branch);
                stmt.setDouble(4, math);
                stmt.setDouble(5, physics);
                stmt.setDouble(6, chemistry);
                stmt.setDouble(7, biology);
                stmt.setDouble(8, literature);
                stmt.setDouble(9, history);
                stmt.setDouble(10, geo);
                stmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "AYT pratik kaydı başarıyla eklendi.");
            }
        } catch (Exception e) {// Hata yakalandığında verilecek mesaj
            JOptionPane.showMessageDialog(null, "Hata: " + e.getMessage());
        }
    }

    public static List<AYTExamRecord> getExamRecords(int studentId) {// Sınav kaydı görme 
        List<AYTExamRecord> records = new ArrayList<>();
        String sql = "SELECT * FROM AYTExamRecord WHERE student_id = ?";// AYTExamRecords'tan girilen ID'ye ait öğrenciyi gösterir
        try (Connection conn = DatabaseConnector.getConnection();// Hata yakalamak için try-catch bloğu
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                records.add(new AYTExamRecord(
                    rs.getString("branch"),
                    rs.getDouble("math"),
                    rs.getDouble("physics"),
                    rs.getDouble("chemistry"),
                    rs.getDouble("biology"),
                    rs.getDouble("literature"),
                    rs.getDouble("history"),
                    rs.getDouble("geo")
                ));
            }
        } catch (SQLException e) {// Hata yakalandığında verilecek mesaj
            e.printStackTrace();
        }
        return records;
    }

    public static List<AYTPracticeRecord> getPracticeRecords(int studentId) {// Pratik kaydı görme
        List<AYTPracticeRecord> records = new ArrayList<>();
        String sql = "SELECT * FROM AYTPracticeRecord WHERE student_id = ?";// AYTPracticeRecords'tan girilen ID'ye ait öğrenciyi gösterir
        try (Connection conn = DatabaseConnector.getConnection();// Hata yakalamak için try-catch bloğu
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                records.add(new AYTPracticeRecord(
                    rs.getString("branch"),
                    rs.getDouble("math"),
                    rs.getDouble("physics"),
                    rs.getDouble("chemistry"),
                    rs.getDouble("biology"),
                    rs.getDouble("literature"),
                    rs.getDouble("history"),
                    rs.getDouble("geo")
                ));
            }
        } catch (SQLException e) {// Hata yakalandığında verilecek mesaj
            e.printStackTrace();
        }
        return records;
    }

    @Override// Override Metod
    public void insertExam(int studentId, String date, int[] corrects, int[] wrongs) {
        double[] netler = new double[7];
        for (int i = 0; i < 7; i++) {
            netler[i] = corrects[i] - (wrongs[i] * 0.25);
        }

        String branch = JOptionPane.showInputDialog("Branş (sayisal / esit):");

        String sql = "INSERT INTO AYTExamRecord (student_id, date, branch, math, physics, chemistry, biology, literature, history, geo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);
            stmt.setString(2, date);
            stmt.setString(3, branch);

            stmt.setDouble(4, netler[0]); 
            stmt.setDouble(5, branch.equals("sayisal") ? netler[1] : 0);
            stmt.setDouble(6, branch.equals("sayisal") ? netler[2] : 0);
            stmt.setDouble(7, branch.equals("sayisal") ? netler[3] : 0);
            stmt.setDouble(8, branch.equals("esit") ? netler[4] : 0);
            stmt.setDouble(9, branch.equals("esit") ? netler[5] : 0);
            stmt.setDouble(10, branch.equals("esit") ? netler[6] : 0);

            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override// Override Metod
    public void insertPractice(int studentId, String date, int[] corrects, int[] wrongs) {
        double[] netler = new double[7];
        for (int i = 0; i < 7; i++) {
            netler[i] = corrects[i] - (wrongs[i] * 0.25);
        }

        String branch = JOptionPane.showInputDialog("Branş (sayisal / esit):");

        String sql = "INSERT INTO AYTPracticeRecord (student_id, date, branch, math, physics, chemistry, biology, literature, history, geo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);
            stmt.setString(2, date);
            stmt.setString(3, branch);

            stmt.setDouble(4, netler[0]); // math
            stmt.setDouble(5, branch.equals("sayisal") ? netler[1] : 0);
            stmt.setDouble(6, branch.equals("sayisal") ? netler[2] : 0);
            stmt.setDouble(7, branch.equals("sayisal") ? netler[3] : 0);
            stmt.setDouble(8, branch.equals("esit") ? netler[4] : 0);
            stmt.setDouble(9, branch.equals("esit") ? netler[5] : 0);
            stmt.setDouble(10, branch.equals("esit") ? netler[6] : 0);

            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
