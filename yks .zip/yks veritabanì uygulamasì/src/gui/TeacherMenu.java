package gui;

import java.awt.*;
import javax.swing.*;
import java.util.List;

import models.Ogrenci;
import records.*;
import manager.*;
import records.Records;

public class TeacherMenu extends JFrame {

    private JTextField tfStudentId;   // Öğrenci ID giriş alanı
    private JTextArea taResults;      // Sonuçları göstermek için metin alanı
    private Ogrenci ogrenci;          // Seçilen öğrenci nesnesi

    // Constructor: Öğretmen menüsü GUI'yi oluşturur
    public TeacherMenu() {
        setTitle("Öğretmen İşlemleri");
        setSize(700, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Başlık etiketi
        JLabel lblTitle = new JLabel("Öğrenci Sonuçları", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 20));

        // Giriş ve işlem butonları
        tfStudentId = new JTextField(15);
        JButton btnSelectStudent = new JButton("Öğrenci Seç");
        JButton btnViewTYTExamResults = new JButton("TYT Sınav Netlerini Görüntüle");
        JButton btnViewTYTPracticeResults = new JButton("TYT Pratik Netlerini Görüntüle");
        JButton btnChartTYTExam = new JButton("TYT Sınav Grafiği");
        JButton btnViewAYTExamResults = new JButton("AYT Sınav Netlerini Görüntüle");
        JButton btnViewAYTPracticeResults = new JButton("AYT Pratik Netlerini Görüntüle");
        JButton btnChartAYTExam = new JButton("AYT Sınav Grafiği");
        JButton btnExit = new JButton("Çıkış");

        // Sonuçların gösterileceği metin alanı
        taResults = new JTextArea(8, 40);
        taResults.setEditable(false);
        taResults.setFont(new Font("Monospaced", Font.PLAIN, 14));

        // Panel yapısı
        JPanel panelTop = new JPanel(new GridLayout(2, 1, 5, 5));
        JPanel panelInput = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        JPanel panelButtons = new JPanel(new GridLayout(2, 4, 10, 10)); // 2 satır, 4 sütun buton düzeni
        JPanel panelResults = new JPanel(new BorderLayout());

        // Giriş paneli: öğrenci ID ve seçim butonu
        panelInput.add(new JLabel("Öğrenci ID:"));
        panelInput.add(tfStudentId);
        panelInput.add(btnSelectStudent);

        // Başlık + giriş panelini üst panele ekle
        panelTop.add(lblTitle);
        panelTop.add(panelInput);

        // Tüm işlem butonlarını ekle
        panelButtons.add(btnViewTYTExamResults);
        panelButtons.add(btnViewTYTPracticeResults);
        panelButtons.add(btnChartTYTExam);
        panelButtons.add(btnViewAYTExamResults);
        panelButtons.add(btnViewAYTPracticeResults);
        panelButtons.add(btnChartAYTExam);
        panelButtons.add(btnExit); // Çıkış en sona

        // Sonuç alanını scroll ile ekle
        panelResults.add(new JScrollPane(taResults), BorderLayout.CENTER);

        // Panelleri ana pencereye yerleştir
        add(panelTop, BorderLayout.NORTH);
        add(panelResults, BorderLayout.CENTER);
        add(panelButtons, BorderLayout.SOUTH);

        // Öğrenci ID seçme butonu işlevi
        btnSelectStudent.addActionListener(e -> {
            try {
                int selectedId = Integer.parseInt(tfStudentId.getText());
                Records.setStudentId(selectedId); // Seçilen ID'yi Records sınıfına set et
                ogrenci = new Ogrenci(selectedId); // Öğrenci nesnesi oluştur
                taResults.setText("Seçilen Öğrenci ID: " + selectedId + "\n" +
                        "İsim: " + ogrenci.getName() + " " + ogrenci.getSurname());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Geçersiz öğrenci ID'si!", "Hata", JOptionPane.ERROR_MESSAGE);
            }
        });

        // TYT sınav sonuçları gösterme
        btnViewTYTExamResults.addActionListener(e ->
                showStats(TYTRecordManager.getExamRecords(Records.getStudentId()), "TYT Sınav Sonuçları"));

        // TYT pratik sonuçları gösterme
        btnViewTYTPracticeResults.addActionListener(e ->
                showStats(TYTRecordManager.getPracticeRecords(Records.getStudentId()), "TYT Pratik Sonuçları"));

        // AYT sınav sonuçları gösterme
        btnViewAYTExamResults.addActionListener(e ->
                showStats(AYTRecordManager.getExamRecords(Records.getStudentId()), "AYT Sınav Sonuçları"));

        // AYT pratik sonuçları gösterme
        btnViewAYTPracticeResults.addActionListener(e ->
                showStats(AYTRecordManager.getPracticeRecords(Records.getStudentId()), "AYT Pratik Sonuçları"));

        // TYT grafiğini aç
        btnChartTYTExam.addActionListener(e ->
                ChartUtils.showTYTLineChart(TYTRecordManager.getExamRecords(Records.getStudentId())));

        // AYT grafiğini aç
        btnChartAYTExam.addActionListener(e ->
                ChartUtils.showAYTLineChart(AYTRecordManager.getExamRecords(Records.getStudentId())));

        // Çıkış işlemi
        btnExit.addActionListener(e -> System.exit(0));
    }

    // Sonuçları istatistiksel olarak metin alanında gösteren yardımcı metot
    private <T extends Records> void showStats(List<T> records, String title) {
        if (records.isEmpty()) {
            taResults.setText(title + ": Kayıt bulunamadı.");
            return;
        }

        double total = 0, max = Double.NEGATIVE_INFINITY, min = Double.POSITIVE_INFINITY;
        for (T rec : records) {
            double net = rec.getTotalNet();
            total += net;
            if (net > max) max = net;
            if (net < min) min = net;
        }
        double avg = total / records.size();

        taResults.setText(title + "\n" +
                "Maksimum Net: " + max + "\n" +
                "Minimum Net: " + min + "\n" +
                "Ortalama Net: " + avg);
    }
}
