package models;
import java.sql.*;
import java.util.Scanner;

import database.DatabaseConnector;
import records.Records;

public class Ogrenci extends Person {// Öğrenci
    private int studentNo;
    private String school;

    public Ogrenci(String name, String surname, String phoneNumber, int studentNo, String school) {// Öğrenci constructor'ı
        super(name, surname, phoneNumber);
        this.studentNo = studentNo;
        this.school = school;
    }
   
	public Ogrenci(String name, String string, String surname, String string2, String password, int i, String string3) {
		
	}

	//Getters - Setters
	public int getStudentNo() {
		return studentNo;
	}

	public void setStudentNo(int studentNo) {
		this.studentNo = studentNo;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public Ogrenci(int studentNo) {
	    this.setStudentNo(studentNo);//Öğrenci numarası ayarlama
	    try (Connection conn = DatabaseConnector.getConnection();//Hata yakalamak için try-catch bloğu
	         PreparedStatement stmt = conn.prepareStatement("SELECT name, surname FROM student WHERE studentNo = ?")) {
	        stmt.setInt(1, studentNo);
	        ResultSet rs = stmt.executeQuery();
	        if (rs.next()) {
	            this.setName(rs.getString("name"));// İsim ayarlama
	            this.setSurname(rs.getString("surname"));// Soyisim ayarlama
	        }
	    } catch (SQLException e) {//Hata yakalandığında verilecek mesaj
	        e.printStackTrace();
	    }
	}


	
 // Öğrenci giriş işlemi
    public boolean login() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Öğrenci ID giriniz: ");
        int id = scanner.nextInt();
        scanner.nextLine();  // Satır sonu karakterini temizleme
        System.out.print("Şifre giriniz: ");
        String password = scanner.nextLine();

        // Veritabanından öğrenci bilgilerini kontrol etme
        String sql = "SELECT * FROM student WHERE studentNo = ? AND password = ?";
        try (Connection conn = DatabaseConnector.getConnection();//Hata yakalamak için try-catch bloğu
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                this.studentNo = id;
                this.school = rs.getString("school");
                Records.setStudentId(id);
                System.out.println("Giriş başarılı. Öğrenci ID: " + Records.getStudentId());
                return true;
            } else {
                System.out.println("Giriş başarısız! Kullanıcı adı veya şifre yanlış.");
                return false;
            }
        } catch (SQLException e) {//Hata yakalandığında verilecek mesaj
            System.err.println("Veritabanı bağlantı hatası: " + e.getMessage());
            return false;
        }
    }


}
