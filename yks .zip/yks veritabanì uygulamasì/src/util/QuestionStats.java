package util;
public class QuestionStats {
	private int right;
	private int wrong;

	public QuestionStats(int right, int wrong) {// Constructor
		this.right = right;
		this.wrong = wrong;
	}
	// Getters - Setters
	public int getRight() {
		return right;
	}

	public void setRight(int right) {
		this.right = right;
	}

	public int getWrong() {
		return wrong;
	}

	public void setWrong(int wrong) {
		this.wrong = wrong;
	}

	public int getTotal() {// Toplam soru sayısı alma metotu
		return getRight() + getWrong();
	}

	public double getNet() {// Net hesaplama metotu
		return right - (wrong / 4.0);
	}
}
