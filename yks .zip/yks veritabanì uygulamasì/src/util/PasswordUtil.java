package util;

import javax.swing.JPasswordField;

public class PasswordUtil {

    /**
     * JPasswordField'den şifreyi güvenli bir şekilde alır.
     * @param passwordField JPasswordField nesnesi
     * @return Şifreyi String olarak döner
     */
    public static String getPassword(JPasswordField passwordField) {
        if (passwordField == null) {// Şifre kısmı null ise karşılaşılacak olan hata mesajı
            throw new IllegalArgumentException("Şifre boş bırakılamaz!" );
        }
        
        char[] passwordChars = passwordField.getPassword();// Şifre, karakter dizisi olarak alınır
        if (passwordChars == null || passwordChars.length == 0) {
            return "";// Eğer hiçbir şey girilmemişse boş string döner
        }
        
        return new String(passwordChars);// Karakter dizisini String'e dönüştürüp geri döndürür
    }
}
