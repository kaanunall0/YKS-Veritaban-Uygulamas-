package records;

public class AYTPracticeRecord extends Records {

	  private String branch;
	    private double math, physics, chemistry, biology, literature, history, geo;

	    public AYTPracticeRecord(String branch, double math, double physics, double chemistry, double biology,// Constructor
	                         double literature, double history, double geo) {
	        this.branch = branch;
	        this.math = math;
	        this.physics = physics;
	        this.chemistry = chemistry;
	        this.biology = biology;
	        this.literature = literature;
	        this.history = history;
	        this.geo = geo;
	    }
	    //Getter
	    public String getBranch() {
	        return branch;
	    }

		@Override// AYT Pratiğinde Toplam Net Alma Metodu
		public double getTotalNet() {
			return math + literature + physics + chemistry + biology + history + geo;
		}
	
}
