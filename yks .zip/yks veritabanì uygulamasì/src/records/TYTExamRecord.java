package records;

public class TYTExamRecord extends Records {

	private double math, turkish, physics, chemistry, biology, history, geo;

    public TYTExamRecord(double math, double turkish, double physics, double chemistry,// Constructor
                         double biology, double history, double geo) {
        this.math = math;
        this.turkish = turkish;
        this.physics = physics;
        this.chemistry = chemistry;
        this.biology = biology;
        this.history = history;
        this.geo = geo;
    }

	@Override// TYT Sınavında Toplam Net Alma Metodu
	public double getTotalNet() {
		return math + turkish + physics + chemistry + biology + history + geo;
	}


	
}
