package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnector {
	//MySQL Girişi
	private static final String url = "jdbc:mysql://localhost:3306/yks_tyt_ayt";
	private static final String username = "root";
	private static final String password = "kaan1234";

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url, username, password);
	}

}